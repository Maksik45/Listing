﻿
namespace MKGlav1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.butColorName = new System.Windows.Forms.Button();
            this.SayHello = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.butReverseCS = new System.Windows.Forms.Button();
            this.butDateTime = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.butScroll_Click = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(285, 10);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(267, 24);
            this.button1.TabIndex = 1;
            this.button1.Text = "Листинг 2.1. Вставка одной строки в другую строку ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(285, 38);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(267, 24);
            this.button2.TabIndex = 2;
            this.button2.Text = "Листинг 2.2. Удаление подстроки из заданной строки";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(558, 10);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(267, 303);
            this.listBox1.TabIndex = 3;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(285, 65);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(267, 24);
            this.button3.TabIndex = 4;
            this.button3.Text = "Листинг 2.3. Извлечение подстроки из заданной строки";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(267, 50);
            this.textBox1.TabIndex = 5;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(11, 68);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(268, 52);
            this.textBox2.TabIndex = 6;
            this.textBox2.Text = "2";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(285, 95);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(267, 24);
            this.button4.TabIndex = 7;
            this.button4.Text = "Листинг 2.4. Определение вхождения подстроки в заданной строке ";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(285, 125);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(267, 24);
            this.button5.TabIndex = 8;
            this.button5.Text = "Листинг 2.5. Преобразование строки в число ";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(285, 154);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(267, 24);
            this.button6.TabIndex = 9;
            this.button6.Text = "Листинг 2.6. Вставка специального символа ";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(285, 183);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(267, 24);
            this.button7.TabIndex = 10;
            this.button7.Text = "Листинг 2.7. Вставка символа торговой марки ";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(285, 212);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(267, 24);
            this.button8.TabIndex = 11;
            this.button8.Text = "Листинг 2.8. Создание строки из повторяющихся символов ";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(285, 240);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(267, 24);
            this.button9.TabIndex = 12;
            this.button9.Text = "Листинг 2.9. Использование метода String.Format";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // butColorName
            // 
            this.butColorName.Location = new System.Drawing.Point(285, 270);
            this.butColorName.Name = "butColorName";
            this.butColorName.Size = new System.Drawing.Size(267, 43);
            this.butColorName.TabIndex = 13;
            this.butColorName.Text = "Листинг 2.10. Преобразование строки в объект Color и обратно ";
            this.butColorName.UseVisualStyleBackColor = true;
            this.butColorName.Click += new System.EventHandler(this.butColorName_Click);
            // 
            // SayHello
            // 
            this.SayHello.Location = new System.Drawing.Point(285, 309);
            this.SayHello.Name = "SayHello";
            this.SayHello.Size = new System.Drawing.Size(267, 42);
            this.SayHello.TabIndex = 14;
            this.SayHello.Text = "Листинг 2.11. Проверка строки на пустоту";
            this.SayHello.UseVisualStyleBackColor = true;
            this.SayHello.Click += new System.EventHandler(this.SayHello_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(285, 346);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(267, 42);
            this.button10.TabIndex = 15;
            this.button10.Text = "Листинг 2.12. Переворачиваем строку при помощи функции Visual Basic ";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // butReverseCS
            // 
            this.butReverseCS.Location = new System.Drawing.Point(285, 385);
            this.butReverseCS.Name = "butReverseCS";
            this.butReverseCS.Size = new System.Drawing.Size(267, 42);
            this.butReverseCS.TabIndex = 16;
            this.butReverseCS.Text = "Листинг 2.13. Переворачиваем строку при помощи C#";
            this.butReverseCS.UseVisualStyleBackColor = true;
            this.butReverseCS.Click += new System.EventHandler(this.butReverseCS_Click);
            // 
            // butDateTime
            // 
            this.butDateTime.Location = new System.Drawing.Point(11, 166);
            this.butDateTime.Name = "butDateTime";
            this.butDateTime.Size = new System.Drawing.Size(267, 42);
            this.butDateTime.TabIndex = 17;
            this.butDateTime.Text = "Листинг 2.19. Вывод даты и времени в разных форматах";
            this.butDateTime.UseVisualStyleBackColor = true;
            this.butDateTime.Click += new System.EventHandler(this.butDateTime_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(11, 126);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(267, 42);
            this.button11.TabIndex = 18;
            this.button11.Text = "Листинг 2.18. Получение текущей даты";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(558, 319);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(267, 43);
            this.button12.TabIndex = 19;
            this.button12.Text = "Листинг 2.14. Замена длинного пути многоточием ";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(558, 366);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(267, 43);
            this.button13.TabIndex = 20;
            this.button13.Text = "Листинг 2.15. Эффект печатающегося текста ";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // butScroll_Click
            // 
            this.butScroll_Click.Location = new System.Drawing.Point(558, 415);
            this.butScroll_Click.Name = "butScroll_Click";
            this.butScroll_Click.Size = new System.Drawing.Size(267, 43);
            this.butScroll_Click.TabIndex = 21;
            this.butScroll_Click.Text = "Листинг 2.15. Эффект печатающегося текста ";
            this.butScroll_Click.UseVisualStyleBackColor = true;
            this.butScroll_Click.Click += new System.EventHandler(this.butScroll_Click_Click);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(830, 505);
            this.Controls.Add(this.butScroll_Click);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.butDateTime);
            this.Controls.Add(this.butReverseCS);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.SayHello);
            this.Controls.Add(this.butColorName);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button butColorName;
        private System.Windows.Forms.Button SayHello;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button butReverseCS;
        private System.Windows.Forms.Button butDateTime;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button butScroll_Click;
        private System.Windows.Forms.Timer timer2;
    }
}

